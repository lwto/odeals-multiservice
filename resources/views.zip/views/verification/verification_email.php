<h2>Hello</h2> <br><br>
Your account has been activated <br><br>

Thanks