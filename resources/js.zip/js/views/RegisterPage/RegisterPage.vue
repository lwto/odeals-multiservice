<template>
  <div>
     <register-form/>
  </div>
</template>
<script>
import RegisterForm from '../../components/Register/RegisterForm.vue'


export default {
  components: { RegisterForm },
}
</script>