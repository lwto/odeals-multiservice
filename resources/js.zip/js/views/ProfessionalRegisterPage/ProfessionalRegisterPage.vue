<template>
  <div>
     <professional-register/>
  </div>
</template>
<script>
import ProfessionalRegister from '../../components/JoinAsProfessional/ProfessionalRegister.vue'


export default {
  components: { ProfessionalRegister },
}
</script>