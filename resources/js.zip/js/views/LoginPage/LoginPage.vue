<template>
  <div>
     <login-form/>
  </div>
</template>
<script>
import LoginForm from '../../components/Login/LoginForm.vue'


export default {
  components: { LoginForm },
}
</script>