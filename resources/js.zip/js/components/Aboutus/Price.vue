<template>
<section class="price padding-top ">
  <div class="container">
    
    <h3 class="text-center mb-5">We Provide Professional Services at a Friendly Price</h3>
    

    <div class="row">
      <div class="col-lg-4">
        <div class="card ">
          <div class="card-header">
            <i class="fas fa-calendar-alt"></i>
            <h5 class="pl-3">Managed & Planned</h5>
          </div>
          <div class="card-body">
            <p class="card-text"><i class="fas fa-angle-right"></i>Fix appointments</p>
            <p class="card-text"><i class="fas fa-angle-right"></i>Half and Full days available</p>
            <p class="card-text"><i class="fas fa-angle-right"></i>Fixed Quotes available</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card ">
          <div class="card-header">
            <i class="fas fa-star"></i>
            <h5 class="pl-3">Trained & Experienced</h5>
          </div>
          <div class="card-body">
            <p class="card-text"><i class="fas fa-angle-right"></i>City and Guilds Trained</p>
            <p class="card-text"><i class="fas fa-angle-right"></i>Extensive Experience</p>
            <p class="card-text"><i class="fas fa-angle-right"></i>Dedicated Handyman</p>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card ">
          <div class="card-header">
            <i class="fas fa-building"></i>
            <h5 class="pl-3">Home & Office</h5>
          </div>
          <div class="card-body">
            <p class="card-text"><i class="fas fa-angle-right"></i>Affordable Rates</p>
            <p class="card-text"><i class="fas fa-angle-right"></i>Special Charity Rates</p>
            <p class="card-text"><i class="fas fa-angle-right"></i>Professional & Personable</p>
          </div>
        </div>
      </div>
    </div>
    </div>
  </div>
</section>
</template>

<style scoped>

p{
  color:black;
}
.price i{
  color:#5F60B9;
  margin-right:15px;
}
.card-header{
  display:flex;
  align-items:center;
  background:transparent;
}
.card-header i{
  font-size:24px;
  
}
.card{
  border:1px solid;
  border-radius:0;
  background:transparent;
}

</style>