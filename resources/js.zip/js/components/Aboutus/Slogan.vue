<template>
<section class="slogan">
  <div class="container">
    <h2 class="text-center">Better Service for better life | ODeals Pro Service</h2>
  </div>
</section>
</template>
<style Scoped>
.slogan{
  padding:100px 0;
  background-color: antiquewhite;
}
</style>