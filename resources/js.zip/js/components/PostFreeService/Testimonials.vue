<template>
  <section class="testimonials my-2">
    <div class="container">
      <h3 class="text-center mb-2">Testimonials</h3>
      <div class="row" style="row-gap:10px;">
          <div class="col-lg-3 col-md-6">
            <div class="py-3 px-3 border">
              <div class="d-flex justify-content-center">
                <img src="https://randomuser.me/api/portraits/women/79.jpg"/>
              </div>
              <p class="text-justify mt-2">
                Great customer support from beginning to end of the process. 
                The team are really informed and go the extra mile at every stage. I would recommend them unreservedly.
              </p>
              <h6 class="mt-3">Sharon Yoa</h6>
              <p class="mt-1">Teacher</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="py-3 px-3 border">
              <div class="d-flex justify-content-center">
                <img src="https://randomuser.me/api/portraits/women/71.jpg"/>
              </div>
              <p class="text-justify mt-2">
                Fantastic company! Excellent customer service, efficient process for services.
              </p>
              <h6 class="mt-3">Chew Lim</h6>
              <p class="mt-1">Senior Advisor</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="py-3 px-3 border">
              <div class="d-flex justify-content-center">
                <img src="https://randomuser.me/api/portraits/men/47.jpg"/>
              </div>
              <p class="text-justify mt-2">
                Great service, efficient communication and a really easy way 
                to get a mortgage with lots of help and support to get the right deal.
              </p>
              <h6 class="mt-3">Raymond Toh</h6>
              <p class="mt-1">Taekwondo Coach</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="py-3 px-3 border">
              <div class="d-flex justify-content-center">
                <img src="https://randomuser.me/api/portraits/women/17.jpg"/>
              </div>
              <p class="text-justify mt-2">
                Great support, I'm contacted them with a problem 
                I was having and they responded and solved it straight away, 
                with excellent communication. Many thanks
              </p>
              <h6 class="mt-3">Taylor</h6>
              <p class="mt-1">Manager</p>
            </div>
          </div>
      </div>
    </div>
  </section>
</template>
<style scoped>
img{
  width:100px;
  width:100px;
  border-radius:50%;
}
</style>