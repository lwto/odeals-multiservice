<template>
  <section class="register-step light-background py-3">
    <div class="container">
      <h3 class="text-center mb-5">How to Get Started!</h3>
      <div class="row justify-content-between" style="row-gap:10px;">
        <div class="col-lg-3">
          <img src="/images/icon/registered.png" />
          <h4 class="mb-2 mt-2">Register As A Seller</h4>
          <p>Create your account with your phone number and email.
             Then, select the category of products you provide and
              submit your business details (documents, credentials, etc).</p>
        </div>
        <div class="col-lg-3">
          <img src="/images/icon/man.png" />
          <h4 class="mb-2 mt-2">Get Verified</h4>
          <p>Our team will verify your details and documents, 
            and approve you once everything is good to go.</p>
        </div>
        <div class="col-lg-3">
          <img src="/images/icon/hand.png" />
          <h4 class="mb-2 mt-2">Begin & Start Earning</h4>
          <p>Offer your products/goods, connect and earn!</p>
        </div>
      </div>
    </div>
  </section>
</template>
<style scoped>
img{
  width:70px;
}
h3{
  font-size:2.3rem;
  font-weight:bolder;
}
h4{
  font-size:1.7rem;
}
</style>